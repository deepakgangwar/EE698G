//
// File: pi_to_pi.h
//
// MATLAB Coder version            : 2.8
// C/C++ source code generated on  : 02-Apr-2017 18:48:16
//
#ifndef __PI_TO_PI_H__
#define __PI_TO_PI_H__

// Include Files
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include "rt_defines.h"
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "EKF_predict_types.h"

// Function Declarations
extern void pi_to_pi(double *angle);

#endif

//
// File trailer for pi_to_pi.h
//
// [EOF]
//
