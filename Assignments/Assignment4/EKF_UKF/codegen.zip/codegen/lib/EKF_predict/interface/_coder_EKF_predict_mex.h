/*
 * File: _coder_EKF_predict_mex.h
 *
 * MATLAB Coder version            : 2.8
 * C/C++ source code generated on  : 02-Apr-2017 18:48:16
 */

#ifndef ___CODER_EKF_PREDICT_MEX_H__
#define ___CODER_EKF_PREDICT_MEX_H__

/* Include Files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "_coder_EKF_predict_api.h"

/* Function Declarations */
extern void mexFunction(int32_T nlhs, mxArray *plhs[], int32_T nrhs, const
  mxArray *prhs[]);

#endif

/*
 * File trailer for _coder_EKF_predict_mex.h
 *
 * [EOF]
 */
