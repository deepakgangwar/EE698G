/* 
 * File: _coder_EKF_predict_info.h 
 *  
 * MATLAB Coder version            : 2.8 
 * C/C++ source code generated on  : 02-Apr-2017 18:48:16 
 */

#ifndef ___CODER_EKF_PREDICT_INFO_H__
#define ___CODER_EKF_PREDICT_INFO_H__
/* Include Files */ 
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */ 
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo();

#endif
/* 
 * File trailer for _coder_EKF_predict_info.h 
 *  
 * [EOF] 
 */
