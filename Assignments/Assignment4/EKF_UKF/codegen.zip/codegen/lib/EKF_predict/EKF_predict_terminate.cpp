//
// File: EKF_predict_terminate.cpp
//
// MATLAB Coder version            : 2.8
// C/C++ source code generated on  : 02-Apr-2017 18:48:16
//

// Include Files
#include "rt_nonfinite.h"
#include "EKF_predict.h"
#include "EKF_update.h"
#include "EKF_predict_terminate.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void EKF_predict_terminate()
{
  // (no terminate code required)
}

//
// File trailer for EKF_predict_terminate.cpp
//
// [EOF]
//
