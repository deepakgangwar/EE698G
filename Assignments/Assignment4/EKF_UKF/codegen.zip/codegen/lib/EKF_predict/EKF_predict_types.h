//
// File: EKF_predict_types.h
//
// MATLAB Coder version            : 2.8
// C/C++ source code generated on  : 02-Apr-2017 18:48:16
//
#ifndef __EKF_PREDICT_TYPES_H__
#define __EKF_PREDICT_TYPES_H__

// Include Files
#include "rtwtypes.h"
#endif

//
// File trailer for EKF_predict_types.h
//
// [EOF]
//
