/*
 * File: rtGetNaN.h
 *
 * MATLAB Coder version            : 2.8
 * C/C++ source code generated on  : 02-Apr-2017 18:48:16
 */

#ifndef __RTGETNAN_H__
#define __RTGETNAN_H__
#include <stddef.h>
#include "rtwtypes.h"
#include "rt_nonfinite.h"

extern real_T rtGetNaN(void);
extern real32_T rtGetNaNF(void);

#endif

/*
 * File trailer for rtGetNaN.h
 *
 * [EOF]
 */
