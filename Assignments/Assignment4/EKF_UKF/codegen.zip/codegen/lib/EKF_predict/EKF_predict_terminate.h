//
// File: EKF_predict_terminate.h
//
// MATLAB Coder version            : 2.8
// C/C++ source code generated on  : 02-Apr-2017 18:48:16
//
#ifndef __EKF_PREDICT_TERMINATE_H__
#define __EKF_PREDICT_TERMINATE_H__

// Include Files
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include "rt_defines.h"
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "EKF_predict_types.h"

// Function Declarations
extern void EKF_predict_terminate();

#endif

//
// File trailer for EKF_predict_terminate.h
//
// [EOF]
//
