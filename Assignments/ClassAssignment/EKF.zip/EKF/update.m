function [x,P]= update(x,P,z,R,idf,lm)
 
% Inputs:
%   x, P -  state and covariance
%   z, R - range-bearing measurements and covariances
%   idf - feature index for each z
 
% Outputs:
%   x, P - updated state and covariance


% <---------------------------- TO DO -------------------------->

 
end        


     
    
    
  

         